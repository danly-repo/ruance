package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.PersonBean;
import bpo.PersonBpo;

/**
 * Servlet implementation class GetPhoneServlet
 */
@WebServlet("/servlet/GetPhoneServlet")
public class GetPhoneServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetPhoneServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String telephone=request.getParameter("telephone");
		String error="";
		List<PersonBean> persons=null;
		try{
			PersonBpo personbpo=new PersonBpo();
			persons=personbpo.getPhone(telephone);
		}catch(Exception e){
			error="查询联系人出错："+e.getMessage();
		}
		
		request.setAttribute("error", error);
		request.setAttribute("persons", persons);
		request.getRequestDispatcher("/person/GetPhone.jsp").forward(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
