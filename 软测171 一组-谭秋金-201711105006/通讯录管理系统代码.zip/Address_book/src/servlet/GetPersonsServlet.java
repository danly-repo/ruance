package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.PersonBean;
import bpo.PersonBpo;

/**
 * Servlet implementation class GetPersonsServlet
 */
@WebServlet("/servlet/GetPersonsServlet")
public class GetPersonsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetPersonsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String pno=request.getParameter("pno");
		String pname=request.getParameter("pname");
		String telephone=request.getParameter("telephone");

		String error="";
		List<PersonBean> persons=null;
		try{
			if(pno.equals("")&&pname.equals("")&&telephone.equals("")){
				PersonBpo personbpo1=new PersonBpo();
				persons=personbpo1.getPersons();
			}else{
				PersonBpo personbpo=new PersonBpo();
				persons=personbpo.getPersons(pno,pname,telephone);
			}
		}catch(Exception e){
			error="查询联系人出错："+e.getMessage();
		}
		
		request.setAttribute("error", error);
		request.setAttribute("persons", persons);
		request.getRequestDispatcher("/person/MagPerson.jsp").forward(request,response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
