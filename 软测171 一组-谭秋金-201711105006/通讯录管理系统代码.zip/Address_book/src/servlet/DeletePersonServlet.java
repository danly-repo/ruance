package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.PersonBean;

/**
 * Servlet implementation class DeleteCourseServlet
 */
@WebServlet("/servlet/DeletePersonServlet")
public class DeletePersonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeletePersonServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String pno=request.getParameter("pno");
		String error="";
		try{
			PersonBean personbean=new PersonBean();
			personbean.setPno(pno);
			personbean.delPersonById(pno);
		}catch(Exception e){
			error="删除[pno:"+pno+"]出错："+e.getMessage();
		}
		request.setAttribute("error", error);
//		request.getRequestDispatcher("/servlet/GetCoursesServlet").forward(request,response);
		request.getRequestDispatcher("/person/MagPerson.jsp").forward(request,response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
