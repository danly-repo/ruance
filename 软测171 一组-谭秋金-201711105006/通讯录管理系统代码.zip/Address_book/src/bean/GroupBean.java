package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import bpo.GroupBpo;
import util.DBConnection;

public class GroupBean {
	private String groupid;
	private String gname;
	
	public String getGroupid() {
		if(groupid==null) groupid="";
		return groupid;
	}
	public void setGroupid(String groupid) {
		this.groupid = groupid;
	}
	public String getGname() {
		if(gname==null) gname="";
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	
	public void updateGroup()throws Exception{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "update fenzu set gname=? where groupid="+this.groupid;
			ps = conn.prepareStatement(sql);
			ps.setString(1, this.gname);
			ps.executeUpdate();
		
		} finally {
			DBConnection.close(rs, ps, conn);
		}
	}

	public void delGroupById(String groupid)throws Exception{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "delete from fenzu where groupid="+groupid;
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
		}catch(Exception e){
			System.out.println("删除分组失败"+e.getMessage());
		} finally {
			DBConnection.close(rs, ps, conn);
		}
	}
	
	public void addGroup()throws Exception{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "insert into fenzu(groupid,gname) values(?,?)";
			ps = conn.prepareStatement(sql);
			ps.setString(1, this.getGroupid());
			ps.setString(2, this.getGname());
			
			ps.executeUpdate();
		}catch(Exception e){
			throw e;
		}finally {
			DBConnection.close(rs, ps, conn);
		}
	}
	
	public Map<String, String> checkGroup()throws Exception{
		Map<String, String> errors = new HashMap<String, String>();
		
		if(gname==null||gname.equals("")) {
			errors.put("gname", "分组不能为空！");
		}else{
			GroupBpo Groupbpo=new GroupBpo();
			GroupBean Group=Groupbpo.getGroupByName(gname);
			if(Group!=null) errors.put("gname", "该分组已存在！");
		}
		if(groupid==null||groupid.equals("")) {
			errors.put("groupid", "编号不能为空！");
		}else{
			GroupBpo Groupbpo=new GroupBpo();
			GroupBean Group=Groupbpo.getGroupById(groupid);
			if(Group!=null) errors.put("groupid", "编号已存在！");
		}
		
		
		
			
		return errors;
	}
	public List<GroupBean> getGroups()throws SQLException{
		List<GroupBean> groups=new ArrayList<GroupBean>();
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from fenzu";
			st = conn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()==true){
				GroupBean tmp=new GroupBean();
				tmp.setGroupid(rs.getString("groupid"));
				tmp.setGname(rs.getString("gname"));
				
				groups.add(tmp);
			}
		} finally {
			DBConnection.close(rs, st, conn);
		}
		return groups;
	}
}
