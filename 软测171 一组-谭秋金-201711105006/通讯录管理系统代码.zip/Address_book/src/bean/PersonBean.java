package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import bpo.GroupBpo;
import bpo.PersonBpo;
import util.DBConnection;

public class PersonBean {
	private String pno;
	private String pname;
	private String sex;
	private String telephone;
	private String address;
	private String gname;

	public String getPno() {
		if(pno==null) pno="";
		return pno;
	}
	public void setPno(String pno) {
		this.pno = pno;
	}
	public String getPname() {
		if(pname==null) pname="";
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getSex() {
		if(sex==null) sex="";
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getTelephone() {
		if(telephone==null) telephone="";
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}	
	public String getAddress() {
		if(address==null) address="";
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGname() {
		if(gname==null) gname="";
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	public void updatePerson()throws Exception{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "update person set pname=?,sex=?,telephone=?,address=?,gname=? "
					   + "where pno="+this.pno;
			ps = conn.prepareStatement(sql);
			ps.setString(1, this.pname);
			ps.setString(2, this.sex);
			ps.setString(3, this.telephone);
			ps.setString(4, this.address);
			ps.setString(5, this.gname);
			ps.executeUpdate();
		
		} finally {
			DBConnection.close(rs, ps, conn);
		}
	}

	public void delPersonById(String pno)throws Exception{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "delete from person where pno="+pno;
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
		}catch(Exception e){
			System.out.println("删除联系人失败"+e.getMessage());
		} finally {
			DBConnection.close(rs, ps, conn);
		}
	}
	
	public void addPerson()throws Exception{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "insert into person(pno,pname,sex,telephone,address,gname) values(?,?,?,?,?,?)";
			ps = conn.prepareStatement(sql);
			ps.setString(1, this.getPno());
			ps.setString(2, this.getPname());
			ps.setString(3, this.getSex());
			ps.setString(4, this.getTelephone());
			ps.setString(5, this.getAddress());
			ps.setString(6, this.getGname());
			ps.executeUpdate();
		}catch(Exception e){
			throw e;
		}finally {
			DBConnection.close(rs, ps, conn);
		}
	}
	
	public Map<String, String> checkPerson()throws Exception{
		Map<String, String> errors = new HashMap<String, String>();
		if(pno==null||pno.equals("")) {
			errors.put("pno", "编号不能为空！");
		}else{
			PersonBpo personbpo=new PersonBpo();
			PersonBean person=personbpo.getPersonById(pno);
			if(person!=null) errors.put("pno", "编号已存在！");
		}
		
		if(pname==null||pname.equals("")) errors.put("pname", "姓名不能为空！");
		if(telephone==null||telephone.equals("")) {
			errors.put("telephone", "电话号码不能为空！");
		}else{
			PersonBpo personbpo=new PersonBpo();
			PersonBean person=personbpo.getpersonBytelephone(telephone);
			if(person!=null) errors.put("telephone", "该号码已存在！");
		}
		if(gname!=null){
			GroupBpo groupbpo=new GroupBpo();
			GroupBean group=groupbpo.getGroupByName(gname);
			if(group==null) errors.put("gname", "该分组不存在！");
		}	
		return errors;
	}
}
