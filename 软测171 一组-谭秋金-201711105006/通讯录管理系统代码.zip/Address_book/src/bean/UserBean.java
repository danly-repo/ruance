package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import util.DBConnection;

public class UserBean {
	private String userid;
	private String username;
	private String password;
	private String confirmpassword;
	
	public String getUserid() {
		if(userid==null) userid="";
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUsername() {
		if(username==null) username="";
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		if(password==null) password="";
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmpassword() {
		return confirmpassword;
	}
	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}
	public boolean validlogin()throws SQLException{
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		boolean successflag=false;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from user where username='"+this.username
					+"' and password='"+this.password+"'";
			st = conn.createStatement();
			rs=st.executeQuery(sql);
			if(rs.next()==true) successflag=true;
		} finally {
			DBConnection.close(rs, st, conn);
		}
		return successflag;
	}

	public void updateUser()throws Exception{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "update user set username=? "
					   + "where userid="+this.userid;
			ps = conn.prepareStatement(sql);
			ps.setString(1, this.username);
			
			ps.executeUpdate();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
	}

	public void delUserById(String userid)throws Exception{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "delete from user where userid="+userid;
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
	}
	/**删除用户个人信息*/
	public void delUserById()throws Exception{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "delete from user where userid="+this.userid;
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
	}
	public void addUser()throws Exception{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "insert into user(userid,username,password)"
					   + " values(?,?,?)";
			ps = conn.prepareStatement(sql);
			ps.setString(1, this.getUserid());
			ps.setString(2, this.getUsername());
			ps.setString(3, this.getPassword());
			
			ps.executeUpdate();
		} catch(Exception e){
			throw e;
		}finally {
			DBConnection.close(rs, ps, conn);
		}
	}
	
	public Map<String, String> checkUser()throws Exception{
		Map<String, String> errors = new HashMap<String, String>();
		if(userid==null||userid.equals("")) {
			errors.put("userid", "[用户编号不能为空！]");
		}else{
			UserBean user=this.getUserById(userid);
			if(user!=null) errors.put("userid", "[用户编号已存在！]");
		}
		
		if(username==null||username.equals("")) errors.put("username", "[用户名不能为空！]");
		if(password==null||password.equals("")) errors.put("password", "[密码不能为空！]");
		if(confirmpassword==null||confirmpassword.equals("")) 
			errors.put("confirmpassword", "[确认密码不能为空！]");
		if(password!=null && confirmpassword!=null && !password.equals(confirmpassword)) 
			errors.put("confirmpassword", "[确认密码与密码不一致！]");
		
		return errors;
	}

	public  UserBean getUserById(String userid)throws SQLException{
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		UserBean user=null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from user where userid="+userid;
			st = conn.createStatement();
			rs=st.executeQuery(sql);
			if(rs.next()==true){
				user=new UserBean();
				user.setUserid(userid);
				user.setUsername(rs.getString("username"));;
				user.setPassword(rs.getString("password"));
				
			}
		} finally {
			DBConnection.close(rs, st, conn);
		}
		return user;
	}

	public List<UserBean> getUsers()throws SQLException{
		List<UserBean> users=new ArrayList<UserBean>();
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from user";
			st = conn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()==true){
				UserBean tmp=new UserBean();
				tmp.setUserid(rs.getString("userid"));
				tmp.setUsername(rs.getString("username"));
				tmp.setPassword(rs.getString("password"));
				
				users.add(tmp);
			}
		} finally {
			DBConnection.close(rs, st, conn);
		}
		return users;
	}

}
