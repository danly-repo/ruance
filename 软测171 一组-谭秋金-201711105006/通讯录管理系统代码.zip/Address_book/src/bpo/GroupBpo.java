package bpo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import bean.GroupBean;
import util.DBConnection;

public class GroupBpo {
	public  GroupBean getGroupById(String groupid)throws SQLException{
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		GroupBean group=null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from fenzu where groupid ="+groupid;
			st = conn.createStatement();
			rs=st.executeQuery(sql);
			if(rs.next()==true){
				group=new GroupBean();
				group.setGroupid(rs.getString("groupid"));
				group.setGname(rs.getString("gname"));
				
			}
			//System.out.print(group);
		} finally {
			DBConnection.close(rs, st, conn);
		}
		
		return  group;
	}
	
	public List<GroupBean> getGroups()throws SQLException{
		List<GroupBean> groups=new ArrayList<GroupBean>();
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from fenzu";
			
			st = conn.createStatement();
			
			rs=st.executeQuery(sql);
			
			while(rs.next()==true){
				
				GroupBean t=new GroupBean();
			
				t.setGroupid(rs.getString("groupid"));
				t.setGname(rs.getString("gname"));
				
				groups.add(t);
			}
		} finally {
			DBConnection.close(rs, st, conn);
		}
		return groups;
	}

	public GroupBean getGroupByName(String gname) throws SQLException {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		GroupBean group=null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from fenzu where gname ='"+gname+"'";
			st = conn.createStatement();
			rs=st.executeQuery(sql);
			if(rs.next()==true){
				group=new GroupBean();
				group.setGroupid(rs.getString("groupid"));
				group.setGname(rs.getString("gname"));
				
			}
		
		} finally {
			DBConnection.close(rs, st, conn);
		}
		
		return  group;
	}
}
