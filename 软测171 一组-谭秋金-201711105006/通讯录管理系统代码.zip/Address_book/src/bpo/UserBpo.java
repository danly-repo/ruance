package bpo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import bean.UserBean;
import util.DBConnection;
import util.Date_String;

public class UserBpo {
	public static final String url = "jdbc:mysql://127.0.0.1/teldb"; // 数据库连接
	public static final String name = "com.mysql.jdbc.Driver"; // 程序驱动
	public static final String user = "root"; // 用户名
	public static final String password = "root"; // 密码
 
	public Connection connection = null; // 数据库连接
	public PreparedStatement preparedStatement = null; // 待查询语句描述对
	/**返回单个user*/
	public  UserBean getUserById(String userid)throws SQLException{
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		UserBean user=null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from user where userid="+userid;
			st = conn.createStatement();
			rs=st.executeQuery(sql);
			if(rs.next()==true){
				user=new UserBean();
				user.setUserid(userid);
				user.setUsername(rs.getString("username"));;
				user.setPassword(rs.getString("password"));
			}
		} finally {
			DBConnection.close(rs, st, conn);
		}
		return user;
	}
	/**返回多个user*/
	public List<UserBean> getUsers()throws SQLException{
		List<UserBean> users=new ArrayList<UserBean>();
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from user";
			st = conn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()==true){
				UserBean tmp=new UserBean();
				tmp.setUserid(String.valueOf(rs.getInt("userid")));
				tmp.setUsername(rs.getString("username"));
				tmp.setPassword(rs.getString("password"));
				users.add(tmp);
			}
		} finally {
			DBConnection.close(rs, st, conn);
		}
		return users;
	}
	
}
