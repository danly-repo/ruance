package bpo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import bean.PersonBean;
import util.DBConnection;

public class PersonBpo {
	public PersonBean getpersonBytelephone(String telephone)throws SQLException{
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		PersonBean person=null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from person where telephone ="+telephone;
			st = conn.createStatement();
			rs=st.executeQuery(sql);
			if(rs.next()==true){
				person=new PersonBean();
				person.setPno(rs.getString("pno"));
				person.setPname(rs.getString("pname"));
				person.setSex(rs.getString("sex"));
				person.setTelephone(rs.getString("telephone"));
				person.setAddress(rs.getString("address"));
				person.setGname(rs.getString("gname"));
			}
			//System.out.print(person);
		} finally {
			DBConnection.close(rs, st, conn);
		}
		
		return  person;
	}

	public  PersonBean getPersonById2(String pno)throws SQLException{
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		PersonBean person=null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from person where pno="+pno;
			st = conn.createStatement();
			rs=st.executeQuery(sql);
			if(rs.next()==true){
				person=new PersonBean();
				person.setPno(rs.getString("pno"));
				person.setPname(rs.getString("pname"));
				person.setSex(rs.getString("sex"));
				person.setTelephone(rs.getString("telephone"));
				person.setAddress(rs.getString("address"));
				person.setGname(rs.getString("gname"));
			}
		} finally {
			DBConnection.close(rs, st, conn);
		}
		return person;
	}
	public List<PersonBean> getPersons()throws SQLException{
		List<PersonBean> persons=new ArrayList<PersonBean>();
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from person";
			st = conn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()==true){
				PersonBean tmp=new PersonBean();
				tmp.setPno(rs.getString("pno"));
				tmp.setPname(rs.getString("pname"));
				tmp.setSex(rs.getString("sex"));
				tmp.setTelephone(rs.getString("telephone"));
				tmp.setAddress(rs.getString("address"));
				tmp.setGname(rs.getString("gname"));
				persons.add(tmp);
			}
		} finally {
			DBConnection.close(rs, st, conn);
		}
		return persons;
	}
	public  PersonBean getPersonById(String pno)throws SQLException{
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		PersonBean person=null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from person where pno ="+pno;
			st = conn.createStatement();
			rs=st.executeQuery(sql);
			if(rs.next()==true){
				person=new PersonBean();
				person.setPno(rs.getString("pno"));
				person.setPname(rs.getString("pname"));
				person.setSex(rs.getString("sex"));
				person.setTelephone(rs.getString("telephone"));
				person.setAddress(rs.getString("address"));
				person.setGname(rs.getString("gname"));
			}
			//System.out.print(person);
		} finally {
			DBConnection.close(rs, st, conn);
		}
		
		return  person;
	}
	public List<PersonBean> getPersons(String pno,String pname, String telephone)throws SQLException{
//		
//		if(pname==null) pname="";
//		if(telephone==null) telephone="";
		
		List<PersonBean> persons=new ArrayList<PersonBean>();
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from person where ifnull(pno,'') like '%"+pno+"%' and ifnull(pname,'') like '%"+pname+"%' and ifnull(telephone,'') like '%"+telephone+"%'";
			st = conn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()==true){
				PersonBean tmp=new PersonBean();
				tmp.setPno(rs.getString("pno"));
				tmp.setPname(rs.getString("pname"));
				tmp.setSex(rs.getString("sex"));
				tmp.setTelephone(rs.getString("telephone"));
				tmp.setAddress(rs.getString("address"));
				tmp.setGname(rs.getString("gname"));
				persons.add(tmp);
			}
		} finally {
			DBConnection.close(rs, st, conn);
		}
		return persons;
	}
	public List<PersonBean> getPerson(String pname)throws SQLException{
//		
//		if(pname==null) pname="";
//		if(telephone==null) telephone="";
		
		List<PersonBean> persons=new ArrayList<PersonBean>();
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from person where ifnull(pname,'') like '%"+pname+"%'";
			st = conn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()==true){
				PersonBean tmp=new PersonBean();
				tmp.setPno(rs.getString("pno"));
				tmp.setPname(rs.getString("pname"));
				tmp.setSex(rs.getString("sex"));
				tmp.setTelephone(rs.getString("telephone"));
				tmp.setAddress(rs.getString("address"));
				tmp.setGname(rs.getString("gname"));
				persons.add(tmp);
			}
		} finally {
			DBConnection.close(rs, st, conn);
		}
		return persons;
	}
	public List<PersonBean> getPhone(String telephone)throws SQLException{
//		
//		if(pname==null) pname="";
//		if(telephone==null) telephone="";
		
		List<PersonBean> persons=new ArrayList<PersonBean>();
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from person where ifnull(telephone,'') like '%"+telephone+"%'";
			st = conn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()==true){
				PersonBean tmp=new PersonBean();
				tmp.setPno(rs.getString("pno"));
				tmp.setPname(rs.getString("pname"));
				tmp.setSex(rs.getString("sex"));
				tmp.setTelephone(rs.getString("telephone"));
				tmp.setAddress(rs.getString("address"));
				tmp.setGname(rs.getString("gname"));
				persons.add(tmp);
			}
		} finally {
			DBConnection.close(rs, st, conn);
		}
		return persons;
	}
	public List<PersonBean> getpersonsBypnameAndtelephone(String pname,String telephone)throws SQLException{
		List<PersonBean> persons=new ArrayList<PersonBean>();
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from person where pname like '%"+pname+"%' and telephone like '%"+telephone+"%'";
			st = conn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()==true){
				PersonBean tmp=new PersonBean();
				tmp.setPno(rs.getString("pno"));
				tmp.setPname(rs.getString("pname"));
				tmp.setSex(rs.getString("sex"));
				tmp.setTelephone(rs.getString("telephone"));
				tmp.setAddress(rs.getString("address"));
				tmp.setGname(rs.getString("gname"));
				persons.add(tmp);
			}
		} finally {
			DBConnection.close(rs, st, conn);
		}
		
		return persons;
	}
	public List<PersonBean> getPersons(String gname)throws SQLException{
		
		List<PersonBean> persons=new ArrayList<PersonBean>();
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from person where gname='"+gname+"'";
			st = conn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()==true){
				PersonBean tmp=new PersonBean();
				tmp.setPno(rs.getString("pno"));
				tmp.setPname(rs.getString("pname"));
				tmp.setSex(rs.getString("sex"));
				tmp.setTelephone(rs.getString("telephone"));
				tmp.setAddress(rs.getString("address"));
				tmp.setGname(rs.getString("gname"));
				persons.add(tmp);
			}
		} finally {
			DBConnection.close(rs, st, conn);
		}
		return persons;
	}
	
}
